// ======================
// ALMACÉN COPIHUE - SISTEMA COMPLETO v7.0
// v7.0: Fix categoría en producto nuevo — usa datos.categoria en vez de hardcodear ALMACEN
//       + actualizarStockMinimos() — calcula col N con promedio 7 días × 2
//       + actualizarEstadisticas() — rotación + stock mínimos en un paso
//       + doGet action 'actualizarEstadisticas'
// v6.9: Fix gananciaReal histórica — qty en gramos (ej: 800) se convierte a kg (0.8) para cálculo correcto
// v6.8: Fix costo productos por peso — nomLimpio no sacaba "(800gr)", no matcheaba con inventario
// v6.7: Fix top histórico — ticket "184" vs "0184" no matcheaban
// v6.6: qty por peso guarda número puro (0.8) en vez de texto (0.8kg)
// v6.5: Fix stock por peso — usaba id "peso_TIMESTAMP" en vez de idOriginal, nunca encontraba la fila
// v6.4: Fix qty esPeso — guardaba gramos (800) en vez de kg (0.8), inflaba top productos
// v6.3: Carrito temporal — guardarCarritoTemp + getCarritoTemp (backup en planilla)
// v6.2: Jueves Cervecero — 1 solo gancho (mejor margen) al 20%, resto 10-15%
// v6.1: Jueves Cervecero — estrategia gancho top 2
// v5.9: setConfig + logInterruptor + rebaja stock kg productos por peso
// v5.8: Nueva hoja Ajuste_Rapido separada de Historial
// ======================

const SS_ID = '1hKeM-13t6wyGD5Ya4Rx9NeUJXsgJoVN4dOb-rklPznA';
const HOJA_INVENTARIO = 'inventario';
const HOJA_CONFIG     = 'config_sistema';
const HOJA_HISTORIAL = 'Historial';
const HOJA_AJUSTE_RAPIDO = 'Ajuste_Rapido';
const HOJA_PROVEEDORES = 'Proveedores';
const MP_ACCESS_TOKEN = 'APP_USR-5614141351834158-022520-6ad6dd5ed431ca58fa841bfd74f0945b-213611899';

// ========== MENÚ UNIFICADO ==========
// ⚠️ UN SOLO onOpen en todo el proyecto. motorInventario.gs NO tiene onOpen propio.
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('🏪 COPIHUE')
    .addItem('📦 Ingresar Productos', 'abrirFormularioIngreso')
    .addSeparator()
    .addItem('📊 Ver Historial', 'irAHistorial')
    .addItem('🔄 Actualizar Todo', 'actualizarTodo')
    .addSeparator()
    .addItem('▶ Actualizar motor inventario', 'actualizarMotorInventario')
    .addItem('📋 Generar lista de compra', 'actualizarListaCompra')
    .addToUi();
  console.log('✅ Menú Copihue creado');
}

// ========== ABRIR FORMULARIO DE INGRESO ==========
function abrirFormularioIngreso() {
  const html = HtmlService.createHtmlOutputFromFile('ingreso')
    .setWidth(520)
    .setHeight(750)
    .setTitle('📦 Ingreso de Mercadería');
  SpreadsheetApp.getUi().showModalDialog(html, '📦 Ingreso de Mercadería - Copihue');
}

// ========== IR A HOJA HISTORIAL ==========
function irAHistorial() {
  const ss = SpreadsheetApp.openById(SS_ID);
  const sheetHistorial = ss.getSheetByName(HOJA_HISTORIAL);
  if (sheetHistorial) {
    ss.setActiveSheet(sheetHistorial);
  } else {
    SpreadsheetApp.getUi().alert('❌ No se encontró la hoja "Historial"');
  }
}

// ========== ACTUALIZAR TODO ==========
// ⚠️ Las funciones del motor muestran su propio alert — no agregar un tercero acá
function actualizarTodo() {
  actualizarMotorInventario();
  actualizarListaCompra();
}

// ========== OBTENER DATOS INICIALES (para formulario ingreso) ==========
function obtenerDatosIniciales() {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheetInventario = ss.getSheetByName(HOJA_INVENTARIO);
    const datos = sheetInventario.getDataRange().getValues();

    const productos = [];
    for (let i = 1; i < datos.length; i++) {
      if (datos[i][0]) {
        productos.push(String(datos[i][0]).trim());
      }
    }

    const proveedoresSet = new Set();
    for (let i = 1; i < datos.length; i++) {
      if (datos[i][4]) {
        proveedoresSet.add(String(datos[i][4]).trim());
      }
    }

    return {
      productos: productos,
      proveedores: Array.from(proveedoresSet).sort()
    };
  } catch (error) {
    console.error('Error obtenerDatosIniciales:', error);
    return { productos: [], proveedores: [] };
  }
}

// ========== OBTENER INFO DE UN PRODUCTO ==========
function obtenerInfoProducto(nombreProducto) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheet = ss.getSheetByName(HOJA_INVENTARIO);
    const datos = sheet.getDataRange().getValues();
    const nombreBuscado = nombreProducto.trim().toUpperCase().replace(/\s+/g, ' ');

    for (let i = 1; i < datos.length; i++) {
      if (!datos[i][0]) continue;
      const nombreEnSheet = String(datos[i][0]).trim().toUpperCase().replace(/\s+/g, ' ');
      if (nombreEnSheet === nombreBuscado) {
        return {
          encontrado: true,
          fila: i + 1,
          precioVenta: datos[i][1] || 0,
          stockActual: datos[i][5] || 0,
          proveedor: datos[i][4] || '',
          categoria: datos[i][2] || '',
          precioCosto: obtenerUltimoCosto(nombreProducto)
        };
      }
    }

    return { encontrado: false, mensaje: 'Producto no existe en inventario' };
  } catch (error) {
    console.error('Error obtenerInfoProducto:', error);
    return { encontrado: false, error: error.toString() };
  }
}

// ========== OBTENER ÚLTIMO PRECIO DE COSTO DESDE HISTORIAL ==========
function obtenerUltimoCosto(nombreProducto) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheetHistorial = ss.getSheetByName(HOJA_HISTORIAL);
    if (!sheetHistorial) return null;

    const datos = sheetHistorial.getDataRange().getValues();
    const nombreBuscado = nombreProducto.trim().toUpperCase();

    for (let i = datos.length - 1; i >= 1; i--) {
      const nombreEnHistorial = String(datos[i][1] || '').trim().toUpperCase();
      if (nombreEnHistorial === nombreBuscado) {
        const costo = datos[i][6];
        if (costo && !isNaN(costo)) return Number(costo);
      }
    }
    return null;
  } catch (error) {
    console.error('Error obtenerUltimoCosto:', error);
    return null;
  }
}

// ========== LEER PROVEEDORES ==========
function leerProveedores() {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    let sheet = ss.getSheetByName(HOJA_PROVEEDORES);

    if (!sheet) {
      sheet = ss.insertSheet(HOJA_PROVEEDORES);
      sheet.getRange(1, 1, 1, 5).setValues([['PROVEEDOR', 'TELEFONO_WA', 'MENSAJE', 'ACTIVO', 'NOTAS']]);
      sheet.getRange(1, 1, 1, 5).setFontWeight('bold');
      sheet.setFrozenRows(1);

      const invSheet = ss.getSheetByName(HOJA_INVENTARIO);
      const invDatos = invSheet.getDataRange().getValues();
      const provSet = new Set();
      for (let i = 1; i < invDatos.length; i++) {
        if (invDatos[i][4]) provSet.add(String(invDatos[i][4]).trim().toUpperCase());
      }
      let fila = 2;
      provSet.forEach(function(nombre) {
        sheet.getRange(fila, 1).setValue(nombre);
        sheet.getRange(fila, 3).setValue('Hola {nombre}! 🛒 Te hago el pedido:\n\n{productos}\n\n¡Gracias!');
        sheet.getRange(fila, 4).setValue('NO');
        fila++;
      });
      console.log('✅ Hoja Proveedores creada con ' + provSet.size + ' proveedores');
    }

    const datos = sheet.getDataRange().getValues();
    const proveedores = [];
    for (let i = 1; i < datos.length; i++) {
      const nombre = String(datos[i][0] || '').trim();
      if (!nombre) continue;
      proveedores.push({
        nombre:   nombre,
        telefono: String(datos[i][1] || '').replace(/\D/g, ''),
        mensaje:  String(datos[i][2] || '').trim(),
        activo:   String(datos[i][3] || '').toUpperCase() === 'SI',
        notas:    String(datos[i][4] || '').trim()
      });
    }

    return { success: true, proveedores: proveedores };
  } catch(e) {
    console.error('Error leerProveedores:', e);
    return { success: false, mensaje: e.toString(), proveedores: [] };
  }
}

// ========== GUARDAR PROVEEDOR ==========
function guardarProveedor(datos) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheet = ss.getSheetByName(HOJA_PROVEEDORES);
    if (!sheet) return { success: false, mensaje: 'Hoja Proveedores no existe' };

    const rows = sheet.getDataRange().getValues();
    const nombreBuscado = String(datos.nombre || '').trim().toUpperCase();
    let filaEncontrada = -1;

    for (let i = 1; i < rows.length; i++) {
      if (String(rows[i][0] || '').trim().toUpperCase() === nombreBuscado) {
        filaEncontrada = i + 1;
        break;
      }
    }

    const fila = [
      datos.nombre.trim().toUpperCase(),
      String(datos.telefono || '').replace(/\D/g, ''),
      datos.mensaje || '',
      datos.activo ? 'SI' : 'NO',
      datos.notas || ''
    ];

    if (filaEncontrada > 0) {
      sheet.getRange(filaEncontrada, 1, 1, 5).setValues([fila]);
    } else {
      sheet.appendRow(fila);
    }

    return { success: true, mensaje: '✅ Proveedor guardado: ' + datos.nombre };
  } catch(e) {
    return { success: false, mensaje: e.toString() };
  }
}

// ========== INGRESAR MERCADERÍA (desde formulario) ==========
function ingresarMercaderia(datos) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheetInventario = ss.getSheetByName(HOJA_INVENTARIO);
    const sheetHistorial = ss.getSheetByName(HOJA_HISTORIAL);

    const producto = datos.producto.trim();
    const cantidad = Number(datos.cantidad);
    const precioCosto = datos.precioCosto;
    const precioVenta = datos.precioVenta;
    const proveedor = datos.proveedor;
    const fechaVencimiento = datos.fechaVencimiento;

    if (!producto) return { success: false, mensaje: 'Nombre de producto vacío' };
    const esAjusteDirecto = datos.stockDirecto !== undefined && datos.stockDirecto !== null;
    if (!esAjusteDirecto && cantidad <= 0) return { success: false, mensaje: 'Cantidad debe ser mayor a 0' };

    const datosInventario = sheetInventario.getDataRange().getValues();
    let filaProducto = -1;
    let stockActual = 0;
    const productoNormalizado = producto.trim().toUpperCase().replace(/\s+/g, ' ');

    for (let i = 1; i < datosInventario.length; i++) {
      if (!datosInventario[i][0]) continue;
      const nombreEnSheet = String(datosInventario[i][0]).trim().toUpperCase().replace(/\s+/g, ' ');
      if (nombreEnSheet === productoNormalizado) {
        filaProducto = i + 1;
        stockActual = Number(datosInventario[i][5]) || 0;
        break;
      }
    }

    // ── PRODUCTO NUEVO ──
    if (filaProducto === -1) {
      const ultimaFila = sheetInventario.getLastRow() + 1;
      const nuevoStock = cantidad;
      const todosLosDatos = sheetInventario.getDataRange().getValues();
      let maxId = 0;
      for (let i = 1; i < todosLosDatos.length; i++) {
        const idRaw = String(todosLosDatos[i][3] || '').replace('ID', '');
        const idNum = parseInt(idRaw);
        if (!isNaN(idNum) && idNum > maxId) maxId = idNum;
      }
      const nuevoId = 'ID' + (maxId + 1);

      const categoriaFinal = (datos.categoria && datos.categoria.trim())
        ? datos.categoria.trim().toUpperCase()
        : 'ALMACEN';

      sheetInventario.getRange(ultimaFila, 1).setValue(producto.toUpperCase());
      sheetInventario.getRange(ultimaFila, 2).setValue(precioVenta || 0);
      sheetInventario.getRange(ultimaFila, 3).setValue(categoriaFinal);
      sheetInventario.getRange(ultimaFila, 4).setValue(nuevoId);
      if (proveedor) sheetInventario.getRange(ultimaFila, 5).setValue(proveedor);
      sheetInventario.getRange(ultimaFila, 6).setValue(nuevoStock);
      if (fechaVencimiento) sheetInventario.getRange(ultimaFila, 16).setValue(fechaVencimiento);

      const fechaNuevo = new Date();
      sheetHistorial.appendRow([
        fechaNuevo, producto, cantidad, nuevoStock, nuevoId,
        proveedor || '', precioCosto || '', precioVenta || '', fechaVencimiento || ''
      ]);

      let mensajeNuevo = '✅ Producto NUEVO creado!\n📦 ' + producto + '\n🆔 ' + nuevoId + '\n📊 Stock inicial: ' + nuevoStock;
      if (precioVenta) mensajeNuevo += '\n💰 Precio venta: $' + precioVenta;
      mensajeNuevo += categoriaFinal === 'ALMACEN' && !datos.categoria
        ? '\n\n⚠️ No se seleccionó categoría (se asignó ALMACEN por defecto)'
        : '\n\n📂 Categoría: ' + categoriaFinal;

      return { success: true, mensaje: mensajeNuevo, nuevoStock: nuevoStock, esNuevo: true };
    }

    // ── PRODUCTO EXISTENTE ──
    const nuevoStock = (datos.stockDirecto !== undefined && datos.stockDirecto !== null)
      ? Number(datos.stockDirecto)
      : stockActual + cantidad;
    sheetInventario.getRange(filaProducto, 6).setValue(nuevoStock);

    if (proveedor) sheetInventario.getRange(filaProducto, 5).setValue(proveedor);
    if (precioVenta && precioVenta > 0) sheetInventario.getRange(filaProducto, 2).setValue(precioVenta);
    if (fechaVencimiento) sheetInventario.getRange(filaProducto, 16).setValue(fechaVencimiento);
    if (datos.nombreNuevo && datos.nombreNuevo.trim()) sheetInventario.getRange(filaProducto, 1).setValue(datos.nombreNuevo.trim().toUpperCase());
    if (datos.categoria && datos.categoria.trim()) sheetInventario.getRange(filaProducto, 3).setValue(datos.categoria.trim().toUpperCase());

    const fecha = new Date();
    sheetHistorial.appendRow([
      fecha, producto, cantidad, nuevoStock, '',
      proveedor || '', precioCosto || '', precioVenta || '', fechaVencimiento || ''
    ]);

    let mensaje = '✅ Ingreso exitoso!\n📦 ' + producto + '\n➕ Cantidad: ' + cantidad + '\n📊 Stock: ' + stockActual + ' → ' + nuevoStock;
    if (precioVenta) mensaje += '\n💰 Precio venta actualizado: $' + precioVenta;

    return { success: true, mensaje: mensaje, nuevoStock: nuevoStock };
  } catch (error) {
    console.error('Error ingresarMercaderia:', error);
    return { success: false, mensaje: 'Error: ' + error.toString() };
  }
}

// ========== AJUSTE RÁPIDO ==========
function ajustarProducto(datos) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheetInventario = ss.getSheetByName(HOJA_INVENTARIO);

    let sheetAjuste = ss.getSheetByName(HOJA_AJUSTE_RAPIDO);
    if (!sheetAjuste) {
      sheetAjuste = ss.insertSheet(HOJA_AJUSTE_RAPIDO);
      sheetAjuste.appendRow([
        'FECHA', 'PRODUCTO', 'NOMBRE ANTES', 'NOMBRE DESPUÉS',
        'STOCK ANTES', 'STOCK DESPUÉS', 'PRECIO ANTES', 'PRECIO DESPUÉS',
        'CATEGORÍA ANTES', 'CATEGORÍA DESPUÉS', 'USUARIO'
      ]);
      sheetAjuste.getRange(1, 1, 1, 11).setBackground('#37474f').setFontColor('white').setFontWeight('bold');
    }

    const producto = String(datos.producto || '').trim();
    if (!producto) return { success: false, mensaje: 'Nombre de producto vacío' };

    const datosInv = sheetInventario.getDataRange().getValues();
    let filaProducto = -1;
    let stockActual = 0, precioActual = 0, catActual = '', nombreActual = '';
    const productoNorm = producto.toUpperCase().replace(/\s+/g, ' ');

    for (let i = 1; i < datosInv.length; i++) {
      if (!datosInv[i][0]) continue;
      const nombreEnSheet = String(datosInv[i][0]).trim().toUpperCase().replace(/\s+/g, ' ');
      if (nombreEnSheet === productoNorm) {
        filaProducto = i + 1;
        nombreActual = String(datosInv[i][0]).trim();
        precioActual = Number(datosInv[i][1]) || 0;
        catActual    = String(datosInv[i][2] || '').trim();
        stockActual  = Number(datosInv[i][5]) || 0;
        break;
      }
    }

    if (filaProducto === -1) return { success: false, mensaje: 'Producto no encontrado: ' + producto };

    const stockNuevo  = (datos.stockDespues !== undefined && datos.stockDespues !== null) ? Number(datos.stockDespues) : stockActual;
    const precioNuevo = datos.precioDespues ? Number(datos.precioDespues) : precioActual;
    const nombreNuevo = datos.nombreNuevo   ? String(datos.nombreNuevo).trim().toUpperCase() : nombreActual;
    const catNueva    = datos.categoriaDespues ? String(datos.categoriaDespues).trim().toUpperCase() : catActual;

    const stockRegistroAntes  = (datos.stockAntes !== undefined && datos.stockAntes !== null) ? Number(datos.stockAntes) : stockActual;
    const precioRegistroAntes = datos.precioAntes ? Number(datos.precioAntes) : precioActual;

    sheetInventario.getRange(filaProducto, 6).setValue(stockNuevo);
    if (precioNuevo !== precioActual)   sheetInventario.getRange(filaProducto, 2).setValue(precioNuevo);
    if (nombreNuevo !== nombreActual)   sheetInventario.getRange(filaProducto, 1).setValue(nombreNuevo);
    if (catNueva    !== catActual)      sheetInventario.getRange(filaProducto, 3).setValue(catNueva);

    const fechaAj = new Date();
    sheetAjuste.appendRow([
      fechaAj, producto,
      nombreActual,          nombreNuevo  !== nombreActual  ? nombreNuevo  : '',
      stockRegistroAntes,    stockNuevo,
      precioRegistroAntes,   precioNuevo  !== precioRegistroAntes ? precioNuevo : '',
      catActual,             catNueva     !== catActual     ? catNueva     : '',
      'POS'
    ]);

    let cambios = [];
    if (stockNuevo !== stockRegistroAntes)   cambios.push('Stock: ' + stockRegistroAntes + ' → ' + stockNuevo);
    if (precioNuevo !== precioRegistroAntes)  cambios.push('Precio: $' + precioRegistroAntes + ' → $' + precioNuevo);
    if (nombreNuevo !== nombreActual)         cambios.push('Nombre: ' + nombreActual + ' → ' + nombreNuevo);
    if (catNueva    !== catActual)            cambios.push('Categoría: ' + catActual + ' → ' + catNueva);

    return { success: true, mensaje: '✅ Ajuste guardado\n' + cambios.join('\n'), stockNuevo: stockNuevo };
  } catch (error) {
    console.error('Error ajustarProducto:', error);
    return { success: false, mensaje: 'Error: ' + error.toString() };
  }
}

// ========== ROTACIÓN AUTOMÁTICA ==========
function calcularRotacionAuto() {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);

    const sheetVentas = ss.getSheetByName('Ventas');
    const ventasMap = {};
    if (sheetVentas) {
      const filas = sheetVentas.getDataRange().getValues();
      const hace30 = new Date();
      hace30.setDate(hace30.getDate() - 30);
      for (let i = 1; i < filas.length; i++) {
        const f = filas[i];
        if (!f[0] || !f[3]) continue;
        const nombre = String(f[3]).trim().toUpperCase();
        if (nombre.includes('TOTAL TICKET') || nombre.startsWith('─')) continue;
        const fecha = f[1] instanceof Date ? f[1] : new Date(f[1]);
        if (isNaN(fecha.getTime()) || fecha < hace30) continue;
        const qty = parseFloat(String(f[4]).replace('gr','').replace('kg','')) || 0;
        ventasMap[nombre] = (ventasMap[nombre] || 0) + qty;
      }
    }

    const sheetHist = ss.getSheetByName(HOJA_HISTORIAL);
    const ingresosMap = {};
    if (sheetHist) {
      const filas = sheetHist.getDataRange().getValues();
      const hace90 = new Date();
      hace90.setDate(hace90.getDate() - 90);
      for (let i = 1; i < filas.length; i++) {
        const f = filas[i];
        if (!f[1]) continue;
        const nombre = String(f[1]).trim().toUpperCase();
        const fecha = f[0] instanceof Date ? f[0] : new Date(f[0]);
        if (isNaN(fecha.getTime()) || fecha < hace90) continue;
        ingresosMap[nombre] = (ingresosMap[nombre] || 0) + 1;
      }
    }

    const rotacionMap = {};
    const todosLosNombres = new Set([...Object.keys(ventasMap), ...Object.keys(ingresosMap)]);

    todosLosNombres.forEach(function(nombre) {
      const u = ventasMap[nombre] || 0;
      const v = ingresosMap[nombre] || 0;

      let bVentas = null;
      if      (u >= 8) bVentas = 5;
      else if (u >= 5) bVentas = 4;
      else if (u >= 3) bVentas = 3;
      else if (u >= 1) bVentas = 2;

      let bRepo = 1;
      if      (v >= 12) bRepo = 5;
      else if (v >= 6)  bRepo = 4;
      else if (v >= 3)  bRepo = 3;
      else if (v >= 1)  bRepo = 2;

      const combinado = bVentas !== null
        ? Math.round(bVentas * 0.7 + bRepo * 0.3)
        : bRepo;

      rotacionMap[nombre] = Math.max(1, Math.min(5, combinado));
    });

    if (calcularRotacionAuto._escribir) {
      const sheetInv = ss.getSheetByName(HOJA_INVENTARIO);
      const invDatos = sheetInv.getDataRange().getValues();
      const COL_ROTACION = 15;
      const actualizaciones = [];
      for (let i = 1; i < invDatos.length; i++) {
        const nombre = String(invDatos[i][0] || '').trim().toUpperCase();
        if (!nombre) continue;
        const rot = rotacionMap[nombre] || (parseInt(invDatos[i][14]) || 1);
        actualizaciones.push({ fila: i + 1, valor: rot });
      }
      actualizaciones.forEach(function(a) {
        sheetInv.getRange(a.fila, COL_ROTACION).setValue(a.valor);
      });
      console.log('✅ Rotación escrita en columna O: ' + actualizaciones.length + ' productos');
    }

    return rotacionMap;

  } catch(e) {
    console.warn('⚠️ calcularRotacionAuto falló, usando columna O:', e.toString());
    return {};
  }
}

function actualizarRotacionPlanilla() {
  calcularRotacionAuto._escribir = true;
  const mapa = calcularRotacionAuto();
  calcularRotacionAuto._escribir = false;
  const total = Object.keys(mapa).length;
  console.log('📊 Rotación actualizada para ' + total + ' productos');
  return { success: true, total: total };
}

// ========== ACTUALIZAR STOCK MÍNIMOS (columna N) ==========
function actualizarStockMinimos() {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheetVentas = ss.getSheetByName('Ventas');
    const sheetInv    = ss.getSheetByName(HOJA_INVENTARIO);
    if (!sheetVentas || !sheetInv) return { success: false, mensaje: 'Faltan hojas' };

    const hoy   = new Date();
    const hace7 = new Date(hoy - 7 * 24 * 60 * 60 * 1000);

    const ventas = sheetVentas.getDataRange().getValues();
    const ventasProd = {};

    for (let i = 1; i < ventas.length; i++) {
      const f = ventas[i];
      const fecha = f[1];
      if (!(fecha instanceof Date) || fecha < hace7) continue;
      const nombre = String(f[3] || '').trim();
      if (!nombre || nombre.includes('TOTAL TICKET') || nombre.startsWith('─')) continue;

      const nomLimpio = nombre
        .replace(/\[PRECIO ESP[^\]]*\]/i, '')
        .replace(/\s*\(\d+gr\)/i, '')
        .replace(/\s*\(\d+\.?\d*kg\)/i, '')
        .trim()
        .toUpperCase();

      const qty = parseFloat(String(f[4] || '0').replace('gr','').replace('kg','')) || 0;
      const esGramos = /\(\d+gr\)/i.test(nombre) && qty >= 50;
      const qtdReal  = esGramos ? qty / 1000 : qty;

      ventasProd[nomLimpio] = (ventasProd[nomLimpio] || 0) + qtdReal;
    }

    const inv = sheetInv.getDataRange().getValues();
    let actualizados = 0;
    let sinDatos = 0;

    for (let i = 1; i < inv.length; i++) {
      const nombre = String(inv[i][0] || '').trim().toUpperCase();
      if (!nombre) continue;

      const totalVendido   = ventasProd[nombre] || 0;
      const promedioDiario = totalVendido / 7;
      const stockMinimo    = promedioDiario > 0
        ? Math.ceil(promedioDiario * 2)
        : 1;

      if (totalVendido === 0) sinDatos++;

      const actualActual = parseInt(inv[i][13]) || 0;
      if (actualActual !== stockMinimo) {
        sheetInv.getRange(i + 1, 14).setValue(stockMinimo);
        actualizados++;
      }
    }

    console.log('✅ Stock mínimos actualizados: ' + actualizados + ' productos');
    return {
      success: true,
      mensaje: '✅ Stock mínimos: ' + actualizados + ' actualizados · ' + sinDatos + ' sin datos',
      actualizados,
      sinDatos
    };

  } catch(e) {
    console.error('Error actualizarStockMinimos:', e);
    return { success: false, mensaje: e.toString() };
  }
}

// ========== ACTUALIZAR ESTADÍSTICAS ==========
function actualizarEstadisticas() {
  const rotacion = actualizarRotacionPlanilla();
  const minimos  = actualizarStockMinimos();
  console.log('📊 Rotación:', rotacion.total, '| Mínimos:', minimos.actualizados);
  return { success: true, rotacion, minimos };
}

// ========== HELPERS MOTOR OFERTAS ==========
function _ofertaDiasVencer_(fila) {
  try {
    const v = fila.length > 15 ? fila[15] : '';
    if (!v) return null;
    const d = v instanceof Date ? v : new Date(v);
    if (isNaN(d.getTime())) return null;
    return Math.round((d - new Date()) / (1000 * 60 * 60 * 24));
  } catch(e) { return null; }
}

function _ofertaDiasDesdePromo_(fila) {
  try {
    const v = fila.length > 17 ? fila[17] : '';
    if (!v) return null;
    const d = v instanceof Date ? v : new Date(v);
    if (isNaN(d.getTime())) return null;
    return Math.round((new Date() - d) / (1000 * 60 * 60 * 24));
  } catch(e) { return null; }
}

function _ofertaPuntaje_(fila) {
  var p = 0;
  var dv = _ofertaDiasVencer_(fila);
  var dp = _ofertaDiasDesdePromo_(fila);
  var stock = parseInt(fila[5]) || 0;
  var rotacion = fila.length > 14 ? (parseInt(fila[14]) || 0) : 0;
  var precio = parseInt(fila[1]) || 0;
  if (dp !== null && dp < 15) return -99;
  if (dv !== null) {
    if (dv <= 3) p += 5;
    else if (dv <= 7 && stock >= 5) p += 4;
  }
  if (rotacion >= 3) p += 3;
  if (precio > 1000) p += 2;
  return p;
}

function _ofertaBuildProducto_(fila, i) {
  var tz = Session.getScriptTimeZone();
  var venc = '';
  try {
    var v = fila.length > 15 ? fila[15] : '';
    if (v) {
      venc = v instanceof Date ? Utilities.formatDate(v, tz, 'yyyy-MM-dd') : String(v).trim();
    }
  } catch(e) {}
  var dpv = _ofertaDiasVencer_(fila);
  var estadoVencimiento = 'ok';
  if (dpv !== null) {
    if (dpv <= 0)  estadoVencimiento = 'vencido';
    else if (dpv <= 3)  estadoVencimiento = 'urgente';
    else if (dpv <= 15) estadoVencimiento = 'proximo';
  }
  return {
    id:                i,
    name:              String(fila[0] || '').trim(),
    price:             parseInt(fila[1]) || 0,
    category:          String(fila[2] || 'ALMACEN').trim().toUpperCase(),
    stock:             parseInt(fila[5]) || 0,
    relampago:         parseInt(fila[6]) || 0,
    destacada:         parseInt(fila[7]) || 0,
    especial:          parseInt(fila[8]) || 0,
    rotacion:          fila.length > 14 ? (parseInt(fila[14]) || 0) : 0,
    vencimiento:       venc,
    diasParaVencer:    dpv,
    estadoVencimiento: estadoVencimiento,  // 'vencido' | 'urgente' | 'proximo' | 'ok'
    puntaje:           _ofertaPuntaje_(fila)
  };
}

function calcularOfertas() {
  var ss = SpreadsheetApp.openById(SS_ID);
  var sheet = ss.getSheetByName(HOJA_INVENTARIO);
  var datos = sheet.getDataRange().getValues();

  // ── Límites de visualización (hardcoded + puede sobreescribirse desde config) ──
  var limites = { relampago: 3, ultimas: 3, especiales: 2, destacadas: 9 };

  var relampagoActivo = [];
  var ultimasUnidades = [];
  var idsUsados = {};
  var candidatosUltimas = [];

  // REGLA DE ORO — ÚLTIMAS UNIDADES:
  // Solo productos CON fecha de vencimiento donde diasStock > diasVencimiento
  // (van a sobrar unidades al vencer) O vencen en ≤15 días
  var hoyUlt = new Date(); hoyUlt.setHours(0,0,0,0);
  for (var i = 1; i < datos.length; i++) {
    var fila = datos[i];
    if (!fila[0]) continue;
    var stock = parseInt(fila[5]) || 0;
    if (stock <= 0) continue;
    var catUlt = String(fila[2] || '').trim().toUpperCase();
    if (catUlt === 'CERVEZAS') continue;

    // Sin vencimiento → nunca entra
    var vencUlt = fila[15];
    if (!vencUlt || !(vencUlt instanceof Date)) continue;
    var vNorm = new Date(vencUlt); vNorm.setHours(0,0,0,0);
    var diasVenc = Math.round((vNorm - hoyUlt) / 86400000);
    if (diasVenc <= 0) continue; // ya vencido

    // Calcular días de stock
    var promDiaUlt = parseFloat(fila[23]) || 0; // col X = PromDia
    var diasStockUlt = promDiaUlt > 0 ? stock / promDiaUlt : 999;

    // Entra si no alcanza a venderlo todo O si vence pronto (≤15 días)
    if (diasStockUlt <= diasVenc && diasVenc > 15) continue;

    var puntajeUlt = _ofertaPuntaje_(fila) + Math.max(0, 100 - diasVenc);
    candidatosUltimas.push({ fila: fila, i: i, p: puntajeUlt, diasVenc: diasVenc });
  }

  var totalCandidatosUltimas = candidatosUltimas.length;
  candidatosUltimas
    .sort(function(a, b) { return b.p - a.p; })
    .slice(0, limites.ultimas)
    .forEach(function(c) {
      var prod = _ofertaBuildProducto_(c.fila, c.i);
      prod.diasParaVencer = c.diasVenc;
      ultimasUnidades.push(prod);
      idsUsados[c.i] = true;
    });

  // ── ¿Está activo Jueves Cervecero hoy? ────────────────────
  // Si está activo, cervezas tienen su propia oferta y no deben
  // aparecer en relámpago / destacadas / especiales.
  var diaIdxJC = [1,2,3,4,5,6,0].indexOf(new Date().getDay()); // 0=Lun…6=Dom
  var cerveceroActivoHoy = false;
  try {
    var ssCfgJC = SpreadsheetApp.openById(SS_ID);
    var shCfgJC = ssCfgJC.getSheetByName(HOJA_CONFIG);
    if (shCfgJC) {
      var cfgJC = shCfgJC.getDataRange().getValues();
      for (var cji = 0; cji < cfgJC.length; cji++) {
        var cjClave = String(cfgJC[cji][0] || '').trim().toLowerCase();
        if (cjClave.includes('jueves cervecero') || cjClave.includes('cervecero')) {
          var cjVal = cfgJC[cji][diaIdxJC + 1];
          cerveceroActivoHoy = (cjVal === 1 || cjVal === '1' || cjVal === true);
          break;
        }
      }
    }
  } catch(eCJ) { /* si falla, no excluir */ }

  // Helper: ¿es cerveza? (misma lógica que getJuevesCervecero)
  function _esCerveza_(fila) {
    var nom = String(fila[0] || '').trim().toUpperCase();
    var cat = String(fila[2] || '').trim().toUpperCase();
    return cat.includes('CERV') || nom.includes('CERVEZA') || nom.includes(' LATA') ||
           nom.includes('BIRRA') || nom.includes(' IPA') || nom.includes(' STOUT') || nom.includes(' PORTER');
  }

  // Candidatos relámpago — incluye TODO con relampago>0 y stock>0
  // Sin filtro de puntaje: el puntaje es para sugerencias automáticas, no para bloquear ofertas manuales
  var candidatosRelampago = [];
  for (var i3 = 1; i3 < datos.length; i3++) {
    var fila3 = datos[i3];
    if (!fila3[0]) continue;
    if (idsUsados[i3]) continue;
    var stock3 = parseInt(fila3[5]) || 0;
    var relampago3 = parseInt(fila3[6]) || 0;
    if (stock3 <= 0 || relampago3 <= 0) continue;
    var cat3 = String(fila3[2] || '').trim().toUpperCase();
    if (cat3 === 'CERVEZAS') continue;                    // espejo del filtro en index.html
    if (cerveceroActivoHoy && _esCerveza_(fila3)) continue; // JC tiene prioridad
    candidatosRelampago.push({ fila: fila3, i: i3, p: _ofertaPuntaje_(fila3) });
  }

  candidatosRelampago
    .sort(function(a, b) { return b.p - a.p; });

  // ── Rotación diaria de relámpago ──────────────────────────────────────────
  // Mismo algoritmo que ROTACION_SISTEMA en index.html: seed = dayOfYear
  // Así seba21 (que lee este resultado) y index (que rota localmente) ven los mismos 3
  var relampagoCandidatosParaRotar = candidatosRelampago; // pool ordenado por puntaje
  if (relampagoCandidatosParaRotar.length > limites.relampago) {
    var tzDateR   = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Argentina/Buenos_Aires' }));
    var dateKeyR  = tzDateR.getFullYear() + '-' +
                    String(tzDateR.getMonth() + 1).padStart(2, '0') + '-' +
                    String(tzDateR.getDate()).padStart(2, '0');
    var argDateR  = new Date(dateKeyR);
    var dayOfYearR = Math.floor((argDateR - new Date(argDateR.getFullYear(), 0, 0)) / 86400000);
    var totalSetsR = Math.ceil(relampagoCandidatosParaRotar.length / limites.relampago);
    var setNumberR = dayOfYearR % totalSetsR;
    var startIdxR  = (setNumberR * limites.relampago) % relampagoCandidatosParaRotar.length;
    var rotadosR   = [];
    for (var rri = 0; rri < limites.relampago; rri++) {
      rotadosR.push(relampagoCandidatosParaRotar[(startIdxR + rri) % relampagoCandidatosParaRotar.length]);
    }
    relampagoCandidatosParaRotar = rotadosR;
  }
  // Pool completo para que seba21 calcule precios correctos en todos los productos con relampago
  var relampagoPoolCompleto = candidatosRelampago.map(function(c) {
    return _ofertaBuildProducto_(c.fila, c.i);
  });

  relampagoCandidatosParaRotar.forEach(function(c) {
    relampagoActivo.push(_ofertaBuildProducto_(c.fila, c.i));
  });

  // Destacadas y Especiales — excluir cervezas si JC activo
  var destacadasActivas = [];
  var especialesActivas = [];
  for (var idx = 1; idx < datos.length; idx++) {
    var fd = datos[idx];
    if (!fd[0]) continue;
    var stockD = parseInt(fd[5]) || 0;
    if (stockD <= 0) continue;
    if (cerveceroActivoHoy && _esCerveza_(fd)) continue; // JC tiene prioridad
    if ((parseInt(fd[7]) || 0) > 0) destacadasActivas.push(_ofertaBuildProducto_(fd, idx));
    if ((parseInt(fd[8]) || 0) > 0) especialesActivas.push(_ofertaBuildProducto_(fd, idx));
  }

  // ── Sobreescribir límite de destacadas desde config_sistema si existe ──
  try {
    var ssCfg = SpreadsheetApp.openById(SS_ID);
    var shCfg = ssCfg.getSheetByName(HOJA_CONFIG);
    if (shCfg) {
      var cfgRows = shCfg.getDataRange().getValues();
      for (var ci = 1; ci < cfgRows.length; ci++) {
        var clave = String(cfgRows[ci][0] || '').trim().toLowerCase();
        if (clave.indexOf('máximo destacadas') !== -1 || clave.indexOf('maximo destacadas') !== -1) {
          for (var cj = 1; cj <= 7; cj++) {
            var v = parseInt(cfgRows[ci][cj]);
            if (!isNaN(v) && v > 0) { limites.destacadas = v; break; }
          }
          break;
        }
      }
    }
  } catch(eCfg) { /* usa el default 9 */ }

  // ── Rotación diaria de especiales ──────────────────────────
  var especialesPool = especialesActivas;
  if (especialesActivas.length > limites.especiales) {
    var tzDate    = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Argentina/Buenos_Aires' }));
    var dateKey   = tzDate.getFullYear() + '-' +
                    String(tzDate.getMonth() + 1).padStart(2, '0') + '-' +
                    String(tzDate.getDate()).padStart(2, '0');
    var argDate   = new Date(dateKey);
    var dayOfYear = Math.floor((argDate - new Date(argDate.getFullYear(), 0, 0)) / 86400000);
    var totalSets = Math.ceil(especialesActivas.length / limites.especiales);
    var setNumber = dayOfYear % totalSets;
    var startIdx  = (setNumber * limites.especiales) % especialesActivas.length;
    var rotados   = [];
    for (var ri = 0; ri < limites.especiales; ri++) {
      rotados.push(especialesActivas[(startIdx + ri) % especialesActivas.length]);
    }
    especialesActivas = rotados;
  }

  // ── Rotación diaria de destacadas (mismo algoritmo) ────────
  var destacadasPool = destacadasActivas.slice(); // pool completo
  var destacadasRotadas = destacadasActivas.slice();
  if (destacadasActivas.length > limites.destacadas) {
    var tzDateD   = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Argentina/Buenos_Aires' }));
    var dateKeyD  = tzDateD.getFullYear() + '-' +
                    String(tzDateD.getMonth() + 1).padStart(2, '0') + '-' +
                    String(tzDateD.getDate()).padStart(2, '0');
    var argDateD  = new Date(dateKeyD);
    var dayOfYearD = Math.floor((argDateD - new Date(argDateD.getFullYear(), 0, 0)) / 86400000);
    var totalSetsD = Math.ceil(destacadasActivas.length / limites.destacadas);
    var setNumberD = dayOfYearD % totalSetsD;
    var startIdxD  = (setNumberD * limites.destacadas) % destacadasActivas.length;
    destacadasRotadas = [];
    for (var rdi = 0; rdi < limites.destacadas; rdi++) {
      destacadasRotadas.push(destacadasActivas[(startIdxD + rdi) % destacadasActivas.length]);
    }
  }

  // ── Leer selección manual de Últimas Unidades (hecha en seba21) ──
  var ultimasSeleccionadas = [];
  try {
    var ssCfgU = SpreadsheetApp.openById(SS_ID);
    var shCfgU = ssCfgU.getSheetByName(HOJA_CONFIG);
    if (shCfgU) {
      var cfgRowsU = shCfgU.getDataRange().getValues();
      for (var ui = 0; ui < cfgRowsU.length; ui++) {
        if (String(cfgRowsU[ui][0]).trim() === 'ultimas_seleccion') {
          var rawU = cfgRowsU[ui][1];
          var tsU  = cfgRowsU[ui][2];
          if (rawU && tsU) {
            var fechaU = new Date(tsU);
            var hoyU   = new Date();
            var mismoDiaU = fechaU.getFullYear() === hoyU.getFullYear()
                         && fechaU.getMonth()    === hoyU.getMonth()
                         && fechaU.getDate()     === hoyU.getDate();
            if (mismoDiaU) {
              var idsU = JSON.parse(rawU);
              // Buscar cada producto por su ID (índice de fila en inventario)
              for (var uj = 0; uj < idsU.length; uj++) {
                var idxU = parseInt(idsU[uj]);
                if (idxU > 0 && idxU < datos.length) {
                  var filaU = datos[idxU];
                  if (filaU && filaU[0]) {
                    var prodU = _ofertaBuildProducto_(filaU, idxU);
                    // Calcular días para vencer
                    var vencU = filaU[15];
                    if (vencU) {
                      var fechaVencU = vencU instanceof Date ? vencU : new Date(String(vencU).trim());
                      if (!isNaN(fechaVencU.getTime())) {
                        var hoyU2 = new Date(); hoyU2.setHours(0,0,0,0);
                        prodU.diasParaVencer = Math.round((fechaVencU - hoyU2) / 86400000);
                      }
                    }
                    ultimasSeleccionadas.push(prodU);
                  }
                }
              }
            }
          }
          break;
        }
      }
    }
  } catch(eU) { /* sin selección guardada */ }

  return {
    success: true,
    relampagoActivo:      relampagoActivo,
    relampagoPool:        relampagoPoolCompleto,
    ultimasUnidades:      ultimasUnidades,
    ultimasSeleccionadas: ultimasSeleccionadas,
    destacadasActivas:    destacadasRotadas,    // ya rotadas — mismas que verán index y seba21
    destacadasPool:       destacadasPool,        // pool completo (para stats)
    especialesActivas:    especialesActivas,
    limites: limites,
    fecha: Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm'),
    stats: {
      totalRelampago:          relampagoActivo.length,
      totalUltimas:            ultimasUnidades.length,
      totalUltimasCandidatos:  totalCandidatosUltimas,
      totalDestacadas:         destacadasActivas.length,
      totalEspeciales:         especialesPool.length,
      especialesMostradas:     especialesActivas.length
    }
  };
}

// ========== MOTOR DE PUNTAJE - SUGERENCIAS ==========
function calcularMotorSugerencias() {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheet = ss.getSheetByName(HOJA_INVENTARIO);
    const datos = sheet.getDataRange().getValues();
    const tz = Session.getScriptTimeZone();
    const hoy = new Date();
    const sugerencias = [];

    for (let i = 1; i < datos.length; i++) {
      const fila = datos[i];
      if (!fila[0]) continue;
      const nombre = String(fila[0] || '').trim();
      const precio = parseInt(fila[1]) || 0;
      const stock = parseInt(fila[5]) || 0;
      const relampago = parseInt(fila[6]) || 0;
      const rotacion = fila.length > 14 ? (parseInt(fila[14]) || 0) : 0;
      if (stock <= 0 || relampago <= 0) continue;

      let diasParaVencer = null;
      try {
        const v = fila.length > 15 ? fila[15] : '';
        if (v) {
          const vDate = v instanceof Date ? v : new Date(v);
          if (!isNaN(vDate.getTime())) diasParaVencer = Math.round((vDate - hoy) / (1000 * 60 * 60 * 24));
        }
      } catch(e) {}

      let diasDesdeUltimaPromo = null;
      try {
        const up = fila.length > 17 ? fila[17] : '';
        if (up) {
          const upDate = up instanceof Date ? up : new Date(up);
          if (!isNaN(upDate.getTime())) diasDesdeUltimaPromo = Math.round((hoy - upDate) / (1000 * 60 * 60 * 24));
        }
      } catch(e) {}

      if (diasDesdeUltimaPromo !== null && diasDesdeUltimaPromo < 15) continue;

      let puntaje = 0;
      if (diasParaVencer !== null) {
        if (diasParaVencer <= 3)  puntaje += 5;
        else if (diasParaVencer <= 7 && stock >= 5) puntaje += 4;
      }
      if (rotacion >= 3) puntaje += 3;
      if (precio > 1000) puntaje += 2;

      let tipo = 'relampago';
      if (diasParaVencer !== null && diasParaVencer <= 3) tipo = 'ultimas';

      sugerencias.push({ id: i, nombre, stock, rotacion, diasParaVencer, diasDesdeUltimaPromo, puntaje, tipo, relampago });
    }

    sugerencias.sort((a, b) => b.puntaje - a.puntaje);
    return { success: true, sugerencias: sugerencias.slice(0, 10), fecha: Utilities.formatDate(hoy, tz, 'yyyy-MM-dd HH:mm') };
  } catch (error) {
    return { success: false, mensaje: error.toString() };
  }
}

// ========== ACTIVAR RELÁMPAGO ==========
function activarRelampago(datos) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheet = ss.getSheetByName(HOJA_INVENTARIO);
    const todosLosDatos = sheet.getDataRange().getValues();
    const productoId = datos.productoId;
    const tipoRelampago = datos.tipo;
    const filaProducto = parseInt(productoId) + 1;
    if (filaProducto < 2 || filaProducto > todosLosDatos.length) return { success: false, mensaje: 'Producto no encontrado' };
    sheet.getRange(filaProducto, 7).setValue(tipoRelampago);
    if (datos.limpiarOfertas && tipoRelampago > 0) {
      sheet.getRange(filaProducto, 8).setValue(0);
      sheet.getRange(filaProducto, 9).setValue(0);
    }
    const nombreProducto = todosLosDatos[filaProducto - 1][0];
    if (tipoRelampago > 0) sheet.getRange(filaProducto, 18).setValue(new Date());
    if (tipoRelampago === 0) return { success: true, mensaje: '✅ Relámpago desactivado: ' + nombreProducto };
    const descuentos = { 11: '10%', 12: '15%', 13: '20%', 14: '25%' };
    const desc = descuentos[tipoRelampago] || tipoRelampago;
    return { success: true, mensaje: '⚡ Relámpago activado! ' + nombreProducto + ' - Descuento: ' + desc };
  } catch (error) {
    return { success: false, mensaje: 'Error: ' + error.toString() };
  }
}

// ========== GET CONFIG ==========
function getConfig() {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheet = ss.getSheetByName(HOJA_CONFIG);
    if (!sheet) return { success: false, mensaje: 'Hoja config_sistema no encontrada' };
    const datos = sheet.getDataRange().getValues();
    const config = {};
    let seccionActual = 'general';
    for (let i = 1; i < datos.length; i++) {
      const clave = String(datos[i][0] || '').trim();
      if (!clave) continue;
      if (clave.startsWith('──') || clave.startsWith('─') || clave.startsWith('📌')) {
        const c = clave.toLowerCase();
        if (c.includes('relámpago') || c.includes('relampago')) seccionActual = 'relampago';
        else if (c.includes('destacada')) seccionActual = 'destacadas';
        else if (c.includes('especial')) seccionActual = 'especiales';
        else if (c.includes('unidad') || c.includes('última') || c.includes('ultima')) seccionActual = 'ultimas';
        else if (c.includes('horario')) seccionActual = 'horario';
        continue;
      }
      const vals = [];
      for (let c = 1; c <= 7; c++) {
        const v = datos[i][c];
        vals.push(v !== '' && v !== null && v !== undefined ? v : null);
      }
      const claveUnica = seccionActual + '|' + clave;
      config[claveUnica] = vals;
      if (!config[clave]) config[clave] = vals;
    }
    return { success: true, config };
  } catch(e) {
    return { success: false, mensaje: e.toString() };
  }
}

// ========== SET CONFIG ==========
function setConfig(datos) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheet = ss.getSheetByName(HOJA_CONFIG);
    if (!sheet) return { success: false, mensaje: 'Hoja config_sistema no encontrada' };

    const seccion  = String(datos.seccion || '').toLowerCase();
    const clave    = String(datos.clave   || '').trim();
    const diaIdx   = parseInt(datos.dia);
    const valor    = datos.valor === 1 || datos.valor === '1' ? 1 : 0;

    if (isNaN(diaIdx) || diaIdx < 0 || diaIdx > 6) return { success: false, mensaje: 'Día inválido' };

    const hojaData = sheet.getDataRange().getValues();
    let seccionActual = 'general';
    let filaObjetivo = -1;
    let filaFallback = -1; // si no matchea sección, usar la primera que matchee por clave

    const claveNorm = clave.toLowerCase();

    for (let i = 1; i < hojaData.length; i++) {
      const celda = String(hojaData[i][0] || '').trim();
      if (!celda) continue;
      if (celda.startsWith('──') || celda.startsWith('─') || celda.startsWith('📌') || celda.startsWith('—')) {
        const c = celda.toLowerCase();
        if (c.includes('relámpago') || c.includes('relampago')) seccionActual = 'relampago';
        else if (c.includes('destacada')) seccionActual = 'destacadas';
        else if (c.includes('especial')) seccionActual = 'especiales';
        else if (c.includes('unidad') || c.includes('última') || c.includes('ultima')) seccionActual = 'ultimas';
        else if (c.includes('horario')) seccionActual = 'horario';
        continue;
      }
      const celdaNorm = celda.toLowerCase();
      // Match exacto con sección
      if (seccionActual === seccion && celdaNorm === claveNorm) {
        filaObjetivo = i + 1;
        break;
      }
      // Fallback: match solo por clave sin importar sección
      if (filaFallback === -1 && celdaNorm === claveNorm) {
        filaFallback = i + 1;
      }
    }

    // Si no encontró con sección, usar fallback
    if (filaObjetivo === -1) filaObjetivo = filaFallback;

    if (filaObjetivo === -1) return { success: false, mensaje: 'No se encontró: ' + seccion + '|' + clave };

    const columna = diaIdx + 2;
    sheet.getRange(filaObjetivo, columna).setValue(valor);

    return { success: true, mensaje: 'OK: ' + seccion + '|' + clave + '[' + diaIdx + '] = ' + valor };
  } catch(e) {
    return { success: false, mensaje: e.toString() };
  }
}

// ========== JUEVES CERVECERO ==========
function getJuevesCervecero() {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheetInv    = ss.getSheetByName(HOJA_INVENTARIO);
    const sheetVentas = ss.getSheetByName('Ventas');
    const sheetCfg    = ss.getSheetByName(HOJA_CONFIG);
    if (!sheetInv) return { success: false, mensaje: 'Sin inventario' };

    let horaCierre = 22;
    if (sheetCfg) {
      const cfgData = sheetCfg.getDataRange().getValues();
      let enHorario = false;
      for (let i = 0; i < cfgData.length; i++) {
        const clave = String(cfgData[i][0] || '').trim().toLowerCase();
        if (clave.includes('horario local') || clave.includes('── horario')) { enHorario = true; continue; }
        if (enHorario && clave.includes('cierre local')) {
          const v = cfgData[i][4];
          if (v !== null && v !== '') {
            const parsed = parseFloat(String(v).split(':')[0]);
            if (!isNaN(parsed)) horaCierre = parsed;
          }
          break;
        }
      }
    }

    const inv = sheetInv.getDataRange().getValues();
    const cervezas = [];
    for (let i = 1; i < inv.length; i++) {
      const nombre = String(inv[i][0] || '').trim();
      const cat    = String(inv[i][2] || '').trim().toUpperCase();
      const precio = parseFloat(inv[i][1]) || 0;
      const stock  = parseInt(inv[i][5]) || 0;
      const costo  = parseFloat(inv[i][18]) || 0;
      if (!nombre || stock < 3 || precio <= 0) continue;
      const esCerveza = cat.includes('CERV') ||
                        nombre.toUpperCase().includes('CERVEZA') ||
                        nombre.toUpperCase().includes(' LATA') ||
                        nombre.toUpperCase().includes('BIRRA') ||
                        nombre.toUpperCase().includes(' IPA') ||
                        nombre.toUpperCase().includes(' STOUT') ||
                        nombre.toUpperCase().includes(' PORTER');
      if (!esCerveza) continue;
      const margen = costo > 0 ? (precio - costo) / precio : 0.35;
      cervezas.push({ i, nombre, precio, stock, costo, margen });
    }

    if (!cervezas.length) return { success: true, productos: [], horaCierre };

    const ventasProd = {};
    const ticketTotales = {};
    if (sheetVentas) {
      const hoy    = new Date();
      const hace30 = new Date(hoy - 30 * 86400000);
      const ventas = sheetVentas.getDataRange().getValues();
      for (let i = 1; i < ventas.length; i++) {
        const f = ventas[i];
        const nombre = String(f[3] || '').trim();
        if (nombre.includes('TOTAL TICKET')) {
          ticketTotales[String(f[0] || '').trim()] = parseFloat(f[7]) || 0;
        }
      }
      for (let i = 1; i < ventas.length; i++) {
        const f = ventas[i];
        const fecha = f[1];
        if (!(fecha instanceof Date) || fecha < hace30) continue;
        const nombre = String(f[3] || '').trim().toUpperCase();
        const qty    = parseFloat(f[4]) || 0;
        const tk     = String(f[0] || '').trim();
        if (!nombre || nombre.startsWith('─')) continue;
        if (!ventasProd[nombre]) ventasProd[nombre] = { qty: 0, tickets: 0, ticketTotal: 0 };
        ventasProd[nombre].qty += qty;
        ventasProd[nombre].tickets++;
        ventasProd[nombre].ticketTotal += ticketTotales[tk] || 0;
      }
    }

    const maxQty    = Math.max(...cervezas.map(c => (ventasProd[c.nombre.toUpperCase()] || {qty:0}).qty), 1);
    const maxStock  = Math.max(...cervezas.map(c => c.stock), 1);
    const maxTicket = Math.max(...cervezas.map(c => (ventasProd[c.nombre.toUpperCase()] || {ticketTotal:0}).ticketTotal), 1);

    const scored = cervezas.map(c => {
      const vd       = ventasProd[c.nombre.toUpperCase()] || { qty: 0, tickets: 0, ticketTotal: 0 };
      const rotScore  = vd.qty / maxQty;
      const stockScore = c.stock / maxStock;
      const margenScore = Math.min(c.margen, 1);
      const ticketScore = vd.ticketTotal / maxTicket;
      const promoScore = (rotScore * 0.35) + (stockScore * 0.25) + (margenScore * 0.20) + (ticketScore * 0.20);
      return { ...c, promoScore, ventas30: vd.qty };
    });

    const top6 = scored.sort((a, b) => b.promoScore - a.promoScore).slice(0, 6);
    const idxGancho = top6.reduce((bestIdx, c, i) => c.margen > top6[bestIdx].margen ? i : bestIdx, 0);

    const top6Final = top6.map((c, idx) => {
      let descuento = idx === idxGancho ? 20 : (c.margen > 0.30 ? 15 : 10);
      const precioBase = Math.max(
        Math.round(c.precio * (1 - descuento / 100)),
        c.costo > 0 ? Math.ceil(c.costo * 1.05) : 0
      );
      // Efecto psicológico: X99 más cercano, nunca por encima del precio original
      const precioPromo99 = Math.round((precioBase - 99) / 100) * 100 + 99;
      const precioPromo = Math.min(precioPromo99, c.precio - 1); // nunca supera el original
      return { ...c, descuento, precioPromo, esGancho: idx === idxGancho };
    });

    return { success: true, productos: top6Final, horaCierre };
  } catch(e) {
    return { success: false, mensaje: e.toString() };
  }
}

function logEventoCerveza(datos) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const HOJA_LOG = 'evento_cerveza_log';
    let sheet = ss.getSheetByName(HOJA_LOG);
    if (!sheet) {
      sheet = ss.insertSheet(HOJA_LOG);
      sheet.appendRow(['FECHA', 'PRODUCTOS', 'UNIDADES VENDIDAS', 'FACTURACIÓN', 'GANANCIA', 'TICKET PROMEDIO', 'DESCUENTO APLICADO']);
      sheet.getRange(1, 1, 1, 7).setBackground('#4a148c').setFontColor('white').setFontWeight('bold');
      [120, 200, 80, 100, 100, 100, 100].forEach((w, i) => sheet.setColumnWidth(i + 1, w));
    }
    const tz = Session.getScriptTimeZone();
    const fecha = Utilities.formatDate(new Date(), tz, 'dd/MM/yyyy HH:mm');
    sheet.appendRow([fecha, String(datos.productos || ''), datos.unidades || 0, datos.facturacion || 0, datos.ganancia || 0, datos.ticketPromedio || 0, String(datos.descuentos || '')]);
    return { success: true };
  } catch(e) {
    return { success: false, mensaje: e.toString() };
  }
}

function logInterruptor(datos) {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const HOJA_LOG = 'Interruptores_Log';
    let sheet = ss.getSheetByName(HOJA_LOG);
    if (!sheet) {
      sheet = ss.insertSheet(HOJA_LOG);
      sheet.appendRow(['FECHA', 'HORA', 'OFERTA', 'ACCIÓN', 'DÍA SEMANA', 'VENDEDOR']);
      sheet.getRange(1, 1, 1, 6).setBackground('#1a237e').setFontColor('white').setFontWeight('bold');
      sheet.setColumnWidth(1, 110); sheet.setColumnWidth(2, 80); sheet.setColumnWidth(3, 120);
      sheet.setColumnWidth(4, 100); sheet.setColumnWidth(5, 120); sheet.setColumnWidth(6, 120);
    }
    const tz = Session.getScriptTimeZone();
    const ahora = new Date();
    const fecha = Utilities.formatDate(ahora, tz, 'dd/MM/yyyy');
    const hora  = Utilities.formatDate(ahora, tz, 'HH:mm:ss');
    const diasNombres = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
    const diaSemana = diasNombres[ahora.getDay()];
    const oferta   = String(datos.tipo     || '').toUpperCase();
    const accion   = datos.estado === 1 ? '🟢 ACTIVADO' : '🔴 DESACTIVADO';
    const vendedor = String(datos.vendedor || 'Desconocido');
    sheet.appendRow([fecha, hora, oferta, accion, diaSemana, vendedor]);
    return { success: true };
  } catch(e) {
    return { success: false, mensaje: e.toString() };
  }
}

// ========== API PRINCIPAL doGet ==========
function doGet(e) {
  try {
    if (e && e.parameter && e.parameter.action === 'vender') {
      return procesarVenta(e.parameter.data);
    }
    if (e && e.parameter && e.parameter.action === 'agregar') {
      return agregarProducto(e.parameter.data);
    }
    if (e && e.parameter && e.parameter.action === 'ingresar') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(ingresarMercaderia(datos));
    }
    if (e && e.parameter && e.parameter.action === 'ajusteRapido') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(ajustarProducto(datos));
    }
    if (e && e.parameter && e.parameter.action === 'setConfig') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(setConfig(datos));
    }
    if (e && e.parameter && e.parameter.action === 'getJuevesCervecero') {
      return respuestaJSON(getJuevesCervecero());
    }
    if (e && e.parameter && e.parameter.action === 'logEventoCerveza') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(logEventoCerveza(datos));
    }
    if (e && e.parameter && e.parameter.action === 'logInterruptor') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(logInterruptor(datos));
    }
    if (e && e.parameter && e.parameter.action === 'crearOrdenMP') {
      const monto = parseFloat(e.parameter.monto) || 0;
      if (monto <= 0) return respuestaJSON({ ok: false, error: 'Monto inválido' });
      return respuestaJSON(crearOrdenMP(monto));
    }
    if (e && e.parameter && e.parameter.action === 'getReportes') {
      try {
        return respuestaJSON(getReportes());
      } catch(errReportes) {
        return respuestaJSON({ error: true, mensaje: 'Error en reportes: ' + errReportes.toString() });
      }
    }
    if (e && e.parameter && e.parameter.action === 'getOfertas') {
      try {
        return respuestaJSON(calcularOfertas());
      } catch(errOfertas) {
        return respuestaJSON({ error: true, mensaje: 'Error en ofertas: ' + errOfertas.toString() });
      }
    }
    if (e && e.parameter && e.parameter.action === 'motorSugerencias') {
      return respuestaJSON(calcularMotorSugerencias());
    }
    if (e && e.parameter && e.parameter.action === 'relampago') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(activarRelampago(datos));
    }
    if (e && e.parameter && e.parameter.action === 'getConfig') {
      return respuestaJSON(getConfig());
    }
    if (e && e.parameter && e.parameter.action === 'actualizarEstadisticas') {
      return respuestaJSON(actualizarEstadisticas());
    }
    if (e && e.parameter && e.parameter.action === 'getProveedores') {
      return respuestaJSON(leerProveedores());
    }
    if (e && e.parameter && e.parameter.action === 'guardarProveedor') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(guardarProveedor(datos));
    }
    if (e && e.parameter && e.parameter.action === 'guardarCarritoTemp') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(guardarCarritoTemp(datos));
    }
    if (e && e.parameter && e.parameter.action === 'getCarritoTemp') {
      return respuestaJSON(getCarritoTemp());
    }
    if (e && e.parameter && e.parameter.action === 'getListaCompra') {
      return respuestaJSON(getListaCompraJSON());
    }
    if (e && e.parameter && e.parameter.action === 'getCandidatosUltimas') {
      return respuestaJSON(getCandidatosUltimas());
    }
    if (e && e.parameter && e.parameter.action === 'guardarUltimasSeleccion') {
      const datos = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(guardarUltimasSeleccion(datos));
    }
    if (e && e.parameter && e.parameter.action === 'getUltimasSeleccion') {
      return respuestaJSON(getUltimasSeleccion());
    }
    if (e && e.parameter && e.parameter.action === 'listarFiados') {
      return respuestaJSON(listarFiados());
    }
    if (e && e.parameter && e.parameter.action === 'cobrarFiado') {
      var datosCobro = e.parameter.data ? JSON.parse(decodeURIComponent(e.parameter.data)) : {};
      return respuestaJSON(cobrarFiado(datosCobro));
    }
    if (e && e.parameter && e.parameter.action === 'guardarFiado') {
      var datosFiado = JSON.parse(decodeURIComponent(e.parameter.data));
      return respuestaJSON(guardarFiado(datosFiado));
    }
    if (e && e.parameter && e.parameter.action === 'consultarFiado') {
      return respuestaJSON(consultarFiado(e.parameter.telefono));
    }

    // ── GET PRODUCTOS (carga la tienda) ──
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheet = ss.getSheetByName(HOJA_INVENTARIO);
    const datos = sheet.getDataRange().getValues();
    const rotacionAuto = calcularRotacionAuto();
    const productos = [];

    for (let i = 1; i < datos.length; i++) {
      const fila = datos[i];
      if (!fila[0]) continue;
      const nombreKey = String(fila[0] || '').trim().toUpperCase();
      const rotacionCalculada = rotacionAuto[nombreKey] || (fila.length > 14 ? (parseInt(fila[14]) || 1) : 1);

      const producto = {
        id: i,
        name: String(fila[0] || '').trim(),
        price: parseInt(fila[1]) || 0,
        category: String(fila[2] || 'ALMACEN').trim().toUpperCase(),
        stock: parseInt(fila[5]) || 0,
        descripcion: fila[3] || '',
        image: '',
        relampago: parseInt(fila[6]) || 0,
        destacada: parseInt(fila[7]) || 0,
        especial: parseInt(fila[8]) || 0,
        normal: 0,
        proveedor: String(fila[4] || '').trim(),
        vencimiento: (() => {
          try {
            const v = fila.length > 15 ? fila[15] : '';
            if (!v) return '';
            if (v instanceof Date) return Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd');
            return String(v).trim();
          } catch(e) { return ''; }
        })(),
        rotacion: rotacionCalculada,
        costo: fila.length > 18 ? (parseFloat(fila[18]) || 0) : 0,
        diaCritico: fila.length > 16 ? String(fila[16] || '').trim().toLowerCase() : '',
        stockMin: parseInt(fila[13]) || 0,
        prioridad: fila.length > 31 ? String(fila[31] || '').trim().toUpperCase() : 'NORMAL',
        ultimaPromo: ''
      };

      if (fila.length > 11) {
        const columnaL = fila[11];
        if (columnaL !== undefined && columnaL !== '' && columnaL !== null) {
          const num = parseInt(columnaL);
          if (!isNaN(num) && num > 0) producto.normal = num;
        }
      }
      if (producto.normal === 0 && fila.length > 10) {
        const columnaK = fila[10];
        if (columnaK !== undefined && columnaK !== '' && columnaK !== null) {
          const num = parseInt(columnaK);
          if (!isNaN(num) && num > 0) producto.normal = num;
        }
      }

      productos.push(producto);
    }

    return ContentService
      .createTextOutput(JSON.stringify({
        productos: productos,
        total: productos.length,
        fecha: new Date().toISOString(),
        version: '7.0'
      }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    console.error('❌ Error API:', error);
    return ContentService
      .createTextOutput(JSON.stringify({ error: true, mensaje: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ========== PROCESAR VENTA ==========
function procesarVenta(dataStr) {
  try {
    const payload = JSON.parse(decodeURIComponent(dataStr));
    const items = Array.isArray(payload) ? payload : (payload.items || []);
    const metodoPago = Array.isArray(payload) ? 'efectivo' : (payload.metodoPago || 'efectivo');
    const vendedor = Array.isArray(payload) ? '' : (payload.vendedor || '');
    const ventaPayload = Array.isArray(payload) ? {} : payload; // para acceder a campos extra

    if (!items || !Array.isArray(items) || items.length === 0) return respuestaJSON({ success: false, mensaje: 'Sin items' });

    const ss = SpreadsheetApp.openById(SS_ID);
    const sheetInventario = ss.getSheetByName(HOJA_INVENTARIO);
    const datos = sheetInventario.getDataRange().getValues();
    const errores = [];
    const procesados = [];
    const fecha = new Date();
    let totalVenta = 0;

    for (const item of items) {
      const filaIndex = item.esPeso ? (item.idOriginal || item.id) : item.id;
      if (filaIndex < 1 || filaIndex >= datos.length) { errores.push('ID ' + item.id + ' no encontrado'); continue; }
      const fila = datos[filaIndex];
      const nombreEnSheet = String(fila[0] || '').trim();
      const stockActual = parseInt(fila[5]) || 0;
      const precioUnit = parseInt(fila[1]) || 0;
      const qty = parseInt(item.qty) || 0;
      const esPeso = item.esPeso === true;
      const gramos = parseInt(item.gramos) || 0;
      const precioVenta = item.precioVenta !== undefined && item.precioVenta !== null && item.precioVenta !== '' ? parseInt(item.precioVenta) : precioUnit;
      const precioOriginal = parseInt(item.precioOriginal) || 0;
      const precioModificado = item.precioModificado === true;
      if (esPeso && gramos <= 0) { errores.push(nombreEnSheet + ': gramos inválidos'); continue; }
      if (!esPeso && qty <= 0) continue;

      if (esPeso) {
        const kgVendidos = gramos / 1000;
        const stockEnKg  = parseFloat(fila[5]) || 0;
        const nuevoStockKg = Math.max(0, Math.round((stockEnKg - kgVendidos) * 1000) / 1000);
        sheetInventario.getRange(filaIndex + 1, 6).setValue(nuevoStockKg);
        const nombreConPeso = gramos > 0 ? nombreEnSheet + ' (' + gramos + 'gr)' : nombreEnSheet;
        const kgDisplay = Math.round(kgVendidos * 1000) / 1000;
        totalVenta += precioVenta;
        procesados.push({ name: nombreConPeso, qty: kgDisplay, nuevoStock: nuevoStockKg, precio: precioVenta, esPeso: true, gramos });
      } else {
        if (stockActual < qty) errores.push(nombreEnSheet + ': stock insuficiente (tiene ' + stockActual + ', vendió ' + qty + ')');
        const nuevoStock = Math.max(0, stockActual - qty);
        sheetInventario.getRange(filaIndex + 1, 6).setValue(nuevoStock);
        totalVenta += precioUnit * qty;
        procesados.push({ name: nombreEnSheet, qty, nuevoStock, precio: precioVenta, precioModificado, precioOriginal });
      }
    }

    try {
      const sheetVentas = ss.getSheetByName('Ventas');
      if (sheetVentas) {
        const hora = Utilities.formatDate(fecha, Session.getScriptTimeZone(), 'HH:mm');
        const filasTotales = sheetVentas.getLastRow();
        let ultimoTicket = 0;
        if (filasTotales > 1) {
          const colA = sheetVentas.getRange(2, 1, filasTotales - 1, 1).getValues();
          for (const fila of colA) {
            const num = parseInt(fila[0]);
            if (!isNaN(num) && num > ultimoTicket) ultimoTicket = num;
          }
        }
        const nroTicket = ultimoTicket + 1;
        const ticketStr = String(nroTicket).padStart(4, '0');

        for (const p of procesados) {
          const filaActual = sheetVentas.getLastRow() + 1;
          const celdaTicket = sheetVentas.getRange(filaActual, 1);
          celdaTicket.setNumberFormat('@STRING@');
          celdaTicket.setValue(ticketStr);
          const subtotal = p.esPeso ? p.precio : p.precio * p.qty;
          const cantDisplay = p.esPeso ? p.qty : p.qty;
          const nombreDisplay = p.precioModificado
            ? p.name + (p.precioOriginal ? ' [PRECIO ESP: $' + p.precioOriginal + '→$' + p.precio + ']' : ' [PRECIO ESPECIAL]')
            : p.name;
          sheetVentas.getRange(filaActual, 2, 1, 6).setValues([[fecha, hora, nombreDisplay, cantDisplay, p.precio, subtotal]]);
        }

        const totalUnidades = procesados.reduce((s, p) => s + (p.esPeso ? 1 : p.qty), 0);
        const metodoPagoEmoji = metodoPago === 'posnet' ? '💳' : metodoPago === 'transferencia' ? '📱' : metodoPago === 'FIADO' ? '🧾' : '💵';
        const clienteInfo = (metodoPago === 'FIADO' && ventaPayload.clienteFiado)
          ? ' | 👤 ' + ventaPayload.clienteFiado + (ventaPayload.telefonoFiado ? ' · ' + ventaPayload.telefonoFiado : '')
          : '';
        sheetVentas.appendRow(['', fecha, hora, '─── TOTAL TICKET N° ' + ticketStr + ' ───', totalUnidades, metodoPagoEmoji + ' ' + metodoPago.toUpperCase() + clienteInfo, vendedor, totalVenta]);
      }
    } catch (e) {
      console.warn('No se pudo registrar en hoja Ventas:', e);
    }

    return respuestaJSON({ success: true, procesados: procesados.length, total: totalVenta, errores: errores, fecha: fecha.toISOString() });
  } catch (error) {
    return respuestaJSON({ success: false, mensaje: error.toString() });
  }
}

// ========== AGREGAR PRODUCTO NUEVO ==========
function agregarProducto(dataStr) {
  try {
    const datos = JSON.parse(decodeURIComponent(dataStr));
    if (!datos.name || !datos.name.trim()) return respuestaJSON({ success: false, mensaje: 'El nombre es obligatorio' });
    if (!datos.price || parseInt(datos.price) <= 0) return respuestaJSON({ success: false, mensaje: 'El precio debe ser mayor a 0' });

    const ss = SpreadsheetApp.openById(SS_ID);
    const sheet = ss.getSheetByName(HOJA_INVENTARIO);
    const datosActuales = sheet.getDataRange().getValues();
    const nombreNuevo = datos.name.trim().toUpperCase().replace(/\s+/g, ' ');

    for (let i = 1; i < datosActuales.length; i++) {
      const nombreExistente = String(datosActuales[i][0] || '').trim().toUpperCase().replace(/\s+/g, ' ');
      if (nombreExistente === nombreNuevo) return respuestaJSON({ success: false, mensaje: 'Ya existe: "' + datosActuales[i][0] + '" en fila ' + (i + 1) });
    }

    const totalFilas = datosActuales.length;
    const idDesc = 'ID' + String(totalFilas).padStart(3, '0');
    const nuevaFila = [
      datos.name.trim().toUpperCase(), parseInt(datos.price) || 0,
      String(datos.category || 'ALMACEN').trim().toUpperCase(), idDesc,
      String(datos.proveedor || '').trim().toUpperCase(), parseInt(datos.stock) || 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, datos.vencimiento || ''
    ];
    sheet.appendRow(nuevaFila);

    try {
      const hojaHistorial = ss.getSheetByName(HOJA_HISTORIAL);
      if (hojaHistorial) {
        hojaHistorial.appendRow([
          new Date(), datos.name.trim().toUpperCase(), parseInt(datos.stock) || 0,
          parseInt(datos.stock) || 0, 'ALTA',
          String(datos.proveedor || '').trim().toUpperCase(),
          parseInt(datos.precioCosto) || 0, parseInt(datos.price) || 0,
          datos.vencimiento ? new Date(datos.vencimiento) : ''
        ]);
      }
    } catch(eHist) { console.warn('⚠️ No se pudo escribir en Historial:', eHist.toString()); }

    return respuestaJSON({ success: true, mensaje: '✅ "' + datos.name.trim() + '" agregado correctamente', fila: totalFilas + 1, id: totalFilas });
  } catch (error) {
    return respuestaJSON({ success: false, mensaje: error.toString() });
  }
}

// ========== HELPERS ==========
function respuestaJSON(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function pruebaRapida() {
  const resultado = doGet(null);
  const json = JSON.parse(resultado.getContent());
  console.log('Versión API:', json.version);
  console.log('Total productos:', json.total);
  return json;
}

// ========== REPORTES COMPLETOS ==========
function getReportes() {
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    const sheetVentas = ss.getSheetByName('Ventas');
    const sheetInv    = ss.getSheetByName(HOJA_INVENTARIO);
    if (!sheetVentas) return { error: 'No existe hoja Ventas' };

    const tz = Session.getScriptTimeZone();
    const filas = sheetVentas.getDataRange().getValues();
    const hoy = new Date();
    const costos = {};
    const sheetHist2 = ss.getSheetByName(HOJA_HISTORIAL);
    const stockInfo = {};

    if (sheetInv) {
      const inv = sheetInv.getDataRange().getValues();
      for (let i = 1; i < inv.length; i++) {
        const nom = String(inv[i][0]||'').trim().toUpperCase();
        const sto = parseInt(inv[i][5]) || 0;
        const cos = parseFloat(inv[i][18]) || 0;
        if (nom) {
          stockInfo[nom] = sto;
          if (cos > 0) costos[nom] = cos;
          // Alias para productos por peso: "ZANAHORIA X KG" → también indexa "ZANAHORIA KG"
          // Cubre el caso en que Ventas registra el nombre sin el " X " intermedio
          const nomAlias = nom.replace(/ X KG$/, ' KG').replace(/ X KG /, ' KG ');
          if (nomAlias !== nom) {
            if (stockInfo[nomAlias] === undefined) stockInfo[nomAlias] = sto;
            if (cos > 0 && !costos[nomAlias]) costos[nomAlias] = cos;
          }
        }
      }
    }
    if (sheetHist2) {
      const hist = sheetHist2.getDataRange().getValues();
      for (let i = 1; i < hist.length; i++) {
        const nom = String(hist[i][1]||'').trim().toUpperCase();
        const cos = parseFloat(hist[i][6]) || 0;
        if (nom && cos > 0 && !costos[nom]) costos[nom] = cos;
      }
    }

    const vencProximos = [];
    if (sheetInv) {
      const inv = sheetInv.getDataRange().getValues();
      const limite = new Date(); limite.setDate(limite.getDate() + 30);
      for (let i = 1; i < inv.length; i++) {
        const nom = String(inv[i][0]||'').trim();
        const stock = parseInt(inv[i][5])||0;
        const venc = inv[i].length > 15 ? inv[i][15] : '';
        if (!venc || !nom) continue;
        let fechaVenc;
        try { fechaVenc = venc instanceof Date ? venc : new Date(venc); } catch(e) { continue; }
        if (isNaN(fechaVenc.getTime())) continue;
        const dias = Math.round((fechaVenc - hoy) / 86400000);
        if (dias <= 30) vencProximos.push({ nombre: nom, stock, fecha: Utilities.formatDate(fechaVenc, tz, 'yyyy-MM-dd'), dias, vencido: dias < 0 });
      }
      vencProximos.sort((a,b) => a.dias - b.dias);
    }

    const items = [];
    const totales = [];

    for (let i = 1; i < filas.length; i++) {
      const f = filas[i];
      const colA  = String(f[0]||'').trim();
      const fecha = f[1];
      if (!fecha || !(fecha instanceof Date)) continue;
      const fechaStr = Utilities.formatDate(fecha, tz, 'yyyy-MM-dd');
      const rawHora = f[2];
      let hora = '';
      if (rawHora instanceof Date) {
        hora = Utilities.formatDate(rawHora, tz, 'HH:mm');
      } else {
        hora = String(rawHora||'').trim();
        const hm = hora.match(/\b(\d{1,2}):(\d{2}):/);
        if (hm) hora = hm[1].padStart(2,'0') + ':' + hm[2];
      }
      const nombre = String(f[3]||'').trim();

      if (nombre.includes('TOTAL TICKET')) {
        const ticketMatch = nombre.match(/N[°ºo]?\s*(\d+)/i);
        const ticket = ticketMatch ? String(ticketMatch[1]).padStart(4,'0') : colA;
        const metodo   = String(f[5]||'').replace(/[💵📱💳🔀🏦]/g,'').trim().toUpperCase();
        const vendedor = String(f[6]||'').trim();
        const total    = parseFloat(f[7]) || 0;
        totales.push({ fechaStr, hora, ticket, metodo, vendedor, total });
      } else if (nombre && !nombre.startsWith('─')) {
        const ticketRaw = String(colA||'').trim();
        const ticket    = ticketRaw.match(/^\d+$/) ? ticketRaw.padStart(4,'0') : ticketRaw;
        const qtyRaw   = f[4];
        const qtyStr   = String(qtyRaw||'').trim();
        let qty        = parseFloat(qtyStr.replace('gr','').replace('kg','')) || 0;
        const esQtyEnGramos = /\(\d+gr\)/i.test(nombre) && qty >= 50;
        if (esQtyEnGramos) qty = qty / 1000;
        const precio   = parseFloat(f[5]) || 0;
        const subtotal = parseFloat(f[6]) || 0;
        const nomLimpio = nombre.replace(/\[PRECIO ESP[^]]*\]/,'').replace(/\s*\(\d+gr\)/i,'').replace(/\s*\(\d+\.?\d*kg\)/i,'').trim().toUpperCase();
        const costo    = costos[nomLimpio] || 0;
        const tieneCosto = costo > 0;
        const gananciaReal = tieneCosto ? subtotal - (costo * qty) : null;
        const gananciaAprox = subtotal * 0.4;
        items.push({ fechaStr, hora, ticket, nombre: nomLimpio, qty, precio, subtotal, costo, gananciaReal, gananciaAprox, tieneCosto });
      }
    }

    const mapaGanancia = {};
    for (const it of items) {
      if (!mapaGanancia[it.nombre]) {
        mapaGanancia[it.nombre] = { nombre: it.nombre, qtdVendida: 0, ingresos: 0, gananciaReal: 0, gananciaAprox: 0, tieneCosto: it.tieneCosto, costo: it.costo };
      }
      const m = mapaGanancia[it.nombre];
      m.qtdVendida  += it.qty;
      m.ingresos    += it.subtotal;
      m.gananciaAprox += it.gananciaAprox;
      if (it.gananciaReal !== null) { m.gananciaReal += it.gananciaReal; m.tieneCosto = true; }
    }

    const topGanancia = Object.values(mapaGanancia)
      .map(p => ({ ...p, ganancia: p.tieneCosto ? p.gananciaReal : p.gananciaAprox, esReal: p.tieneCosto }))
      .filter(p => p.ganancia > 0)
      .sort((a, b) => b.ganancia - a.ganancia)
      .slice(0, 20);

    return { items, totales, vencProximos, stockInfo, topGanancia };
  } catch(e) {
    return { error: e.toString() };
  }
}

// ========== MERCADO PAGO ==========
function crearOrdenMP(monto) {
  try {
    const payload = {
      items: [{ title: 'Compra Almacén Copihue', quantity: 1, unit_price: parseFloat(monto), currency_id: 'ARS' }],
      payment_methods: { excluded_payment_types: [], installments: 1 },
      statement_descriptor: 'ALMACEN COPIHUE',
      expires: true,
      expiration_date_from: new Date().toISOString(),
      expiration_date_to: new Date(Date.now() + 30 * 60 * 1000).toISOString()
    };
    const resp = UrlFetchApp.fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'post',
      headers: { 'Authorization': 'Bearer ' + MP_ACCESS_TOKEN, 'Content-Type': 'application/json' },
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    });
    const data = JSON.parse(resp.getContentText());
    if (data.init_point) return { ok: true, url: data.init_point, id: data.id };
    return { ok: false, error: JSON.stringify(data) };
  } catch(e) {
    return { ok: false, error: e.toString() };
  }
}

// ========== CARRITO TEMPORAL ==========
function guardarCarritoTemp(payload) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sh = ss.getSheetByName('carrito_temp');
    if (!sh) {
      sh = ss.insertSheet('carrito_temp');
      sh.getRange(1,1,1,3).setValues([['timestamp','vendedor','items_json']]);
    }
    const data = typeof payload === 'string' ? JSON.parse(payload) : payload;
    if (!data.items || data.items.length === 0) {
      if (sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow()-1, 3).clearContent();
      return { success: true, action: 'cleared' };
    }
    if (sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow()-1, 3).clearContent();
    sh.getRange(2,1,1,3).setValues([[new Date().toISOString(), data.vendedor || '', JSON.stringify(data.items)]]);
    return { success: true, action: 'saved', count: data.items.length };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

function getCarritoTemp() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sh = ss.getSheetByName('carrito_temp');
    if (!sh || sh.getLastRow() < 2) return { success: true, items: [] };
    const row = sh.getRange(2,1,1,3).getValues()[0];
    const ts = row[0];
    if (ts && (Date.now() - new Date(ts).getTime()) > 8 * 60 * 60 * 1000) {
      sh.getRange(2, 1, 1, 3).clearContent();
      return { success: true, items: [] };
    }
    const items = row[2] ? JSON.parse(row[2]) : [];
    return { success: true, items, vendedor: row[1] || '', ts: ts ? new Date(ts).toISOString() : '' };
  } catch(e) {
    return { success: false, error: e.toString(), items: [] };
  }
}

// ========== LISTA DE COMPRA JSON (para seba21) ==========
function getListaCompraJSON() {
  try {
    var ss = SpreadsheetApp.openById(SS_ID);

    // Leer Lista de compra
    var shLista = ss.getSheetByName('Lista de compra');
    if (!shLista) return { ok: false, error: 'Hoja "Lista de compra" no encontrada. Ejecutá "Actualizar lista de compra" primero.' };
    var listaData = shLista.getDataRange().getValues();
    if (listaData.length <= 1) return { ok: false, error: 'Lista vacía. Ejecutá "Actualizar lista de compra" desde el menú COPIHUE.' };

    // Leer inventario para enriquecer con diasStock, urgencia y rotación
    var shInv = ss.getSheetByName('inventario');
    var invMap = {};
    if (shInv) {
      var invData = shInv.getDataRange().getValues();
      for (var i = 1; i < invData.length; i++) {
        var row = invData[i];
        var nombre = String(row[0] || '').trim();
        if (!nombre) continue;
        invMap[nombre] = {
          categoria: String(row[2] || '').trim().toUpperCase(),  // col C
          v7:        parseFloat(row[21]) || 0,
          v30:       parseFloat(row[22]) || 0,
          diasStock: row[24] !== '' && row[24] !== null ? (parseFloat(row[24]) || 0) : null,
          riesgo:    String(row[30] || '').trim().toUpperCase(),
          prioridad: String(row[31] || '').trim().toUpperCase(),
          pisoManu:  row[32] !== '' && row[32] !== null ? parseFloat(row[32]) : null,
          alertaPiso: String(row[33] || '').trim().toUpperCase()
        };
      }
    }

    // Leer Historial para obtener último precio de costo por producto
    var costoMap = {};
    var shHist = ss.getSheetByName(HOJA_HISTORIAL);
    if (shHist) {
      var histData = shHist.getDataRange().getValues();
      // Recorrer de atrás hacia adelante → primer match = más reciente
      for (var h = histData.length - 1; h >= 1; h--) {
        var nomHist = String(histData[h][1] || '').trim().toUpperCase();
        var costoHist = parseFloat(histData[h][6]) || 0;
        if (nomHist && costoHist > 0 && !costoMap[nomHist]) {
          costoMap[nomHist] = costoHist;
        }
      }
    }

    var items = [];
    var totalPesos = 0;
    var urgentes = 0;

    for (var j = 1; j < listaData.length; j++) {
      var lr = listaData[j];
      var nombre = String(lr[0] || '').trim();
      if (!nombre || nombre.startsWith('──')) continue;

      var stock     = parseFloat(lr[1]) || 0;
      var minimo    = parseFloat(lr[2]) || 0;
      var cantidad  = parseFloat(lr[3]) || 0;
      var precio    = parseFloat(lr[4]) || 0;
      var total     = parseFloat(lr[5]) || 0;
      var proveedor = String(lr[6] || '').trim();

      var inv = invMap[nombre] || {};

      // Excluir categorías que no se recompran
      var catInv = inv.categoria || '';
      if (catInv === 'COMPUTACION' || catInv === 'ELECTRONICA' || catInv === 'TECNOLOGIA') continue;

      var diasStock = inv.diasStock !== undefined ? inv.diasStock : null;
      var v7  = inv.v7  || 0;
      var v30 = inv.v30 || 0;
      var riesgo    = inv.riesgo    || '';
      var prioridad = inv.prioridad || '';
      var alertaPiso = inv.alertaPiso || '';

      // Calcular urgencia según reglas de Javier:
      // 0 = piso manual PEDIR YA
      // 1 = alta rotación sin stock (v30>15 y stock=0) O prioridad EMPUJAR YA
      // 2 = riesgo vencimiento (ALERTA)
      // 3 = stock crítico ≤3 días
      // 4 = stock bajo ≤7 días
      // 5 = baja rotación solo si vendió +2 en 15 días (v7>=2 y stock=0)
      // 7 = compra normal
      var urgencia;
      var altaRotacion = v30 > 15;

      if (alertaPiso === 'PEDIR YA') {
        urgencia = 0;
      } else if ((altaRotacion && stock === 0) || prioridad === 'EMPUJAR YA') {
        urgencia = 1;
      } else if (riesgo === 'ALERTA') {
        urgencia = 2;
      } else if (diasStock !== null && diasStock <= 3) {
        urgencia = 3;
      } else if (diasStock !== null && diasStock <= 7) {
        urgencia = 4;
      } else if (v7 >= 2 && stock === 0) {
        // Baja rotación pero vendió +2 en 15 días → incluir
        urgencia = 5;
      } else {
        urgencia = 7;
      }

      if (urgencia <= 2) urgentes++;
      var nomKey = nombre.trim().toUpperCase();
      var costo = costoMap[nomKey] || 0;
      var totalCosto = costo > 0 ? Math.round(costo * cantidad) : 0;
      totalPesos += totalCosto > 0 ? totalCosto : total;

      var nomKey = nombre.trim().toUpperCase();
      var costo = costoMap[nomKey] || 0;
      var totalCosto = costo > 0 ? Math.round(costo * cantidad) : 0;

      items.push({
        nombre:     nombre,
        stock:      stock,
        minimo:     minimo,
        cantidad:   cantidad,
        precio:     precio,       // precio de VENTA (referencia)
        costo:      costo,        // precio de COSTO desde Historial
        total:      totalCosto > 0 ? totalCosto : total, // usar costo si está disponible
        totalVenta: total,        // total con precio de venta (para referencia)
        proveedor:  proveedor,
        diasStock:  diasStock,
        urgencia:   urgencia,
        prioridad:  prioridad || (urgencia <= 2 ? 'URGENTE' : 'OK')
      });
    }

    // Ordenar por urgencia
    items.sort(function(a, b) { return a.urgencia - b.urgencia; });

    return {
      ok:         true,
      items:      items,
      urgentes:   urgentes,
      totalPesos: totalPesos,
      generadoEn: new Date().toISOString()
    };
  } catch(e) {
    return { ok: false, error: e.toString() };
  }
}

// ========== ÚLTIMAS UNIDADES — CANDIDATOS Y SELECCIÓN ==========

function getCandidatosUltimas() {
  try {
    var ss    = SpreadsheetApp.openById(SS_ID);
    var shInv = ss.getSheetByName(HOJA_INVENTARIO);
    if (!shInv) return { ok: false, error: 'Hoja inventario no encontrada' };

    var datos = shInv.getDataRange().getValues();
    var hoy   = new Date(); hoy.setHours(0,0,0,0);
    var candidatos = [];

    for (var i = 1; i < datos.length; i++) {
      var row      = datos[i];
      var nombre   = String(row[0] || '').trim();
      if (!nombre) continue;

      var precio   = parseFloat(row[1])  || 0;
      var categoria= String(row[2] || '').trim().toUpperCase();
      var stock    = parseFloat(row[5])  || 0;
      var relampago= parseInt(row[6])    || 0;
      var venc     = row[15];
      var v7       = parseFloat(row[21]) || 0;   // col V
      var v30      = parseFloat(row[22]) || 0;   // col W
      var promDia  = parseFloat(row[23]) || 0;   // col X
      var diasStock= row[24] !== '' ? parseFloat(row[24]) : null; // col Y

      if (stock <= 0) continue;               // sin stock no hay nada que empujar
      if (categoria === 'CERVEZAS') continue;

      // Días hasta vencimiento — acepta Date o string "yyyy-MM-dd"
      var diasVenc = null;
      if (venc) {
        var fechaVenc = venc instanceof Date ? venc : new Date(String(venc).trim());
        if (!isNaN(fechaVenc.getTime())) {
          var vNorm = new Date(fechaVenc); vNorm.setHours(0,0,0,0);
          diasVenc = Math.round((vNorm - hoy) / 86400000);
        }
      }

      // CONDICIÓN PRINCIPAL: el producto no se va a vender todo antes de vencer
      // diasStock > diasVenc → va a sobrar stock al vencimiento → EMPUJAR
      var score = null;
      var motivo = '';

      if (diasVenc !== null && diasVenc > 0 && diasStock !== null) {
        if (diasStock > diasVenc) {
          // Cuántas unidades van a sobrar
          var sobran = Math.round(stock - (promDia * diasVenc));
          var pctRiesgo = Math.round((diasStock / diasVenc - 1) * 100); // % de exceso
          score = pctRiesgo; // mayor % = más urgente
          motivo = 'Vence en ' + diasVenc + 'd · stock para ' + Math.round(diasStock) + 'd · sobran ~' + Math.max(sobran, 0) + ' u.';
        }
      }

      // CONDICIÓN SECUNDARIA: alta rotación con stock muy justo (puede quedarse sin stock)
      // Solo si no tiene vencimiento claro
      if (score === null && promDia > 0 && diasStock !== null && diasStock <= 7) {
        score = 0 - diasStock; // negativo = más urgente cuanto menos días
        motivo = 'Stock para solo ' + Math.round(diasStock) + 'd · vende ' + v7 + ' por semana';
      }

      if (score === null) continue; // no cumple ninguna condición

      // Buscar oferta configurada
      var ofertaKey  = String(relampago || '');
      var ofertaDesc = '';
      if (ofertaKey === '10') ofertaDesc = '2da 50%';
      else if (ofertaKey === '11') ofertaDesc = '-10%';
      else if (ofertaKey === '12') ofertaDesc = '-15%';
      else if (ofertaKey === '13') ofertaDesc = '-20%';
      else if (ofertaKey === '14') ofertaDesc = '-25%';
      else if (['1','2','3','4','5','6'].indexOf(ofertaKey) !== -1) {
        var nxm = {1:'2x1',2:'3x2',3:'4x3',4:'5x4',5:'6x5',6:'7x6'};
        ofertaDesc = nxm[ofertaKey] || '';
      }

      candidatos.push({
        id:         i,
        nombre:     nombre,
        precio:     precio,
        categoria:  categoria,
        stock:      stock,
        relampago:  relampago,
        ofertaDesc: ofertaDesc,
        diasVenc:   diasVenc,
        diasStock:  diasStock !== null ? Math.round(diasStock) : null,
        promDia:    promDia,
        v7:         v7,
        v30:        v30,
        score:      score,
        motivo:     motivo
      });
    }

    // Ordenar: mayor score primero (más urgente)
    candidatos.sort(function(a, b) { return b.score - a.score; });

    return { ok: true, candidatos: candidatos, total: candidatos.length };

  } catch(e) {
    return { ok: false, error: e.toString() };
  }
}

function guardarUltimasSeleccion(datos) {
  try {
    var ss = SpreadsheetApp.openById(SS_ID);
    var sh = ss.getSheetByName('config_sistema');
    if (!sh) return { ok: false, error: 'config_sistema no encontrada' };

    // Guardar en una celda específica como JSON
    // Buscar fila "ultimas_seleccion" o usar celda fija K2
    var filas = sh.getDataRange().getValues();
    var filaObj = -1;
    for (var i = 0; i < filas.length; i++) {
      if (String(filas[i][0]).trim() === 'ultimas_seleccion') { filaObj = i + 1; break; }
    }
    if (filaObj === -1) {
      // Agregar al final
      filaObj = filas.length + 1;
      sh.getRange(filaObj, 1).setValue('ultimas_seleccion');
    }
    sh.getRange(filaObj, 2).setValue(JSON.stringify(datos));
    sh.getRange(filaObj, 3).setValue(new Date().toISOString());

    return { ok: true };
  } catch(e) {
    return { ok: false, error: e.toString() };
  }
}

function getUltimasSeleccion() {
  try {
    var ss = SpreadsheetApp.openById(SS_ID);
    var sh = ss.getSheetByName('config_sistema');
    if (!sh) return { ok: true, seleccion: [] };

    var filas = sh.getDataRange().getValues();
    for (var i = 0; i < filas.length; i++) {
      if (String(filas[i][0]).trim() === 'ultimas_seleccion') {
        var raw = filas[i][1];
        var ts  = filas[i][2];
        if (!raw) return { ok: true, seleccion: [] };

        // Verificar que la selección es de hoy
        var fecha = new Date(ts);
        var hoy   = new Date();
        var mismodia = fecha.getFullYear() === hoy.getFullYear()
                    && fecha.getMonth()    === hoy.getMonth()
                    && fecha.getDate()     === hoy.getDate();

        if (!mismodia) return { ok: true, seleccion: [], expirada: true };
        return { ok: true, seleccion: JSON.parse(raw) };
      }
    }
    return { ok: true, seleccion: [] };
  } catch(e) {
    return { ok: true, seleccion: [] };
  }
}

// ══════════════════════════════════════════════
function listarFiados() {
  try {
    var ss = SpreadsheetApp.openById(SS_ID);
    var sh = ss.getSheetByName(HOJA_FIADOS);
    if (!sh) return { ok: false, error: 'Hoja FIADOS no encontrada' };
    var datos = sh.getDataRange().getValues();
    var hoy = new Date(); hoy.setHours(0,0,0,0);
    var fiados = [];
    for (var i = 1; i < datos.length; i++) {
      var fila = datos[i];
      if (!fila[0]) continue;
      var estado = String(fila[10] || '').toUpperCase();
      if (estado === 'PAGADO') continue; // no mostrar pagados
      // Recalcular si venció
      var vencFecha = fila[9] ? new Date(String(fila[9]).split('T')[0] + 'T12:00:00') : null;
      if (vencFecha && vencFecha < hoy && estado !== 'PAGADO') estado = 'VENCIDO';
      fiados.push({
        fila:            i + 1,
        idFiado:         String(fila[0] || ''),
        fecha:           String(fila[1] || ''),
        ticket:          String(fila[2] || ''),
        cliente:         String(fila[3] || ''),
        telefono:        String(fila[4] || ''),
        descripcion:     String(fila[5] || ''),
        cantItems:       fila[6] || 0,
        total:           parseFloat(fila[8]) || 0,
        fechaVencimiento: fila[9] ? String(fila[9]).split('T')[0] : '',
        estado:          estado
      });
    }
    fiados.sort(function(a, b) {
      // Vencidos primero, luego por fecha de vencimiento
      if (a.estado === 'VENCIDO' && b.estado !== 'VENCIDO') return -1;
      if (b.estado === 'VENCIDO' && a.estado !== 'VENCIDO') return 1;
      return (a.fechaVencimiento || '').localeCompare(b.fechaVencimiento || '');
    });
    return { ok: true, fiados: fiados };
  } catch(e) {
    return { ok: false, error: e.toString() };
  }
}

function cobrarFiado(datos) {
  try {
    if (!datos.idFiado) return { success: false, mensaje: 'Falta ID del fiado' };
    var ss = SpreadsheetApp.openById(SS_ID);
    var sh = ss.getSheetByName(HOJA_FIADOS);
    if (!sh) return { success: false, mensaje: 'Hoja FIADOS no encontrada' };
    var rows = sh.getDataRange().getValues();
    for (var i = 1; i < rows.length; i++) {
      if (String(rows[i][0]) === String(datos.idFiado)) {
        var fechaPago = datos.fechaPago || Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
        sh.getRange(i + 1, 11).setValue('PAGADO');        // K: Estado
        sh.getRange(i + 1, 12).setValue(fechaPago);       // L: Fecha Pago
        sh.getRange(i + 1, 13).setValue(datos.metodoPago || 'EFECTIVO'); // M: Método Pago
        return { success: true };
      }
    }
    return { success: false, mensaje: 'Fiado no encontrado: ' + datos.idFiado };
  } catch(e) {
    return { success: false, mensaje: e.toString() };
  }
}

// FIADOS — guardar y consultar
// ══════════════════════════════════════════════
var HOJA_FIADOS = 'FIADOS';

function guardarFiado(datos) {
  try {
    var ss = SpreadsheetApp.openById(SS_ID);
    var sh = ss.getSheetByName(HOJA_FIADOS);
    if (!sh) return { success: false, mensaje: 'Hoja FIADOS no encontrada' };

    var now = new Date();
    var tz  = Session.getScriptTimeZone();
    var fechaStr = Utilities.formatDate(now, tz, 'yyyy-MM-dd HH:mm');

    // Calcular ID_FIADO autoincrementalL
    var ultimaFila = sh.getLastRow();
    var numFiado = ultimaFila; // fila 1 = header, fila 2 = primer fiado
    var idFiado = datos.idFiado || ('FIADO-' + String(numFiado).padStart(4, '0'));

    // Estado automático
    var venc = datos.vencimiento ? new Date(datos.vencimiento) : null;
    var estado = 'PENDIENTE';

    sh.appendRow([
      idFiado,                    // A: ID_FIADO
      fechaStr,                   // B: Fecha
      datos.ticket || '',         // C: Ticket
      datos.cliente || '',        // D: Cliente
      datos.telefono || '',       // E: Teléfono
      datos.descripcion || 'TICKET COMPLETO', // F: Producto/Descripción
      datos.cantItems || 1,       // G: Cantidad
      datos.total || 0,           // H: Precio Unitario (total ticket)
      datos.total || 0,           // I: Total
      datos.vencimiento || '',    // J: Fecha Vencimiento
      '',                         // K: Estado — la fórmula =SI(L<>"";"PAGADO";SI(HOY()>J;"VENCIDO";"PENDIENTE")) lo calcula
      '',                         // L: Fecha Pago
      '',                         // M: Método Pago
      datos.obs || ''             // N: Observaciones
    ]);

    // Insertar fórmula de estado en la celda K de la nueva fila
    var nuevaFila = sh.getLastRow();
    sh.getRange(nuevaFila, 11).setFormula(
      '=SI(D' + nuevaFila + '="";"";SI(L' + nuevaFila + '<>"";"PAGADO";SI(Y(J' + nuevaFila + '<>"";HOY()>FECHANUMERO(J' + nuevaFila + '));"VENCIDO";"PENDIENTE")))'
    );

    return { success: true, idFiado: idFiado };
  } catch(e) {
    return { success: false, mensaje: e.toString() };
  }
}

function consultarFiado(telefono) {
  try {
    if (!telefono) return { ok: true, deuda: null };
    var ss = SpreadsheetApp.openById(SS_ID);
    var sh = ss.getSheetByName(HOJA_FIADOS);
    if (!sh) return { ok: true, deuda: null };

    var datos = sh.getDataRange().getValues();
    var telBuscar = String(telefono).replace(/\D/g, ''); // solo números

    var totalDeuda = 0;
    var pendientes = 0;
    var vencidos = 0;
    var nombreCliente = '';
    var hoy = new Date(); hoy.setHours(0,0,0,0);

    for (var i = 1; i < datos.length; i++) {
      var fila = datos[i];
      var telFila = String(fila[4] || '').replace(/\D/g, '');
      if (telFila !== telBuscar) continue;

      var estado = String(fila[10] || '').toUpperCase();
      if (estado === 'PAGADO') continue; // no contar los pagados

      // Recalcular estado por si venció
      var fechaVenc = fila[9] ? new Date(fila[9]) : null;
      if (fechaVenc && fechaVenc < hoy && estado !== 'PAGADO') {
        estado = 'VENCIDO';
      }

      var total = parseFloat(fila[8]) || 0;
      totalDeuda += total;
      pendientes++;
      if (estado === 'VENCIDO') vencidos++;
      if (!nombreCliente && fila[3]) nombreCliente = String(fila[3]);
    }

    if (pendientes === 0) return { ok: true, deuda: null };

    return {
      ok: true,
      deuda: {
        nombre: nombreCliente,
        total: totalDeuda,
        pendientes: pendientes,
        vencidos: vencidos
      }
    };
  } catch(e) {
    return { ok: true, deuda: null };
  }
}
